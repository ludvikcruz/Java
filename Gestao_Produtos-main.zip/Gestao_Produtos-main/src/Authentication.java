public interface Authentication {
    Boolean authenticate(String username, String password);
}
