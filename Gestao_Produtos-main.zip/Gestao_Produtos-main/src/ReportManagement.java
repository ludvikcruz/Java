import java.util.Date;

public interface ReportManagement {
    Report generateReport(Date startDate, Date endDate);
}
